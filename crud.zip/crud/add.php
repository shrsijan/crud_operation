
    <?php
    require './incl/header.php';
    require './incl/nav.php';
    ?>

    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                Add New Post
            </div>
            <div class="card-body">
                <form action="create.php" method="post">
                    <div class="mb-3">
                        <label for="title" class="form-label">Post Title</label>
                        <input type="text" class="form-control" id="title" name="title">
                    </div>
                    <div class="mb-3">
                        <label for="body" class="form-label">Post Content</label>
                        <textarea class="form-control" id="body" rows="3" name="content"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-warning">Reset</button>
                    <a href="list.php" class="btn btn-danger">Cancel</a>
                </form>
            </div>
        </div>
    </div>

    <?php
    require('./incl/footer.php');
    ?>


    