<?php
    require './incl/header.php';
    require './incl/nav.php';
    require 'dbconfig.php';
    $stmt="SELECT * FROM posts";
    $result= mysqli_query($connection, $stmt);      
    
    ?>

<div class="container mt-4">
    <div class="d-flex flex-row-reverse mb-3">
        <a href="add.php" class="btn btn-primary">Add New</a>
    </div>
    <div class="card">
        <div class="card-header">
            List of posts
        </div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Body</th>
                    <th scope="col">Created At</th>
                    <th scope="col" style="width: 18%">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i=1;
                while($row=mysqli_fetch_array($result))
                {
                ?>
                <tr>
                    <th scope="row"><?=$i;?></th>
                    <td><?php echo $row['title']; ?></td>
                    <td><?=$row['content'];?></td>
                    <td><?=$row['created_at'];?></td>
                    <td>                        
                        <a href="edit.php?id=<?=$row['id'];?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="delete.php?id=<?=$row['id'];?>" class="btn btn-danger btn-sm">Delete</a>
                    </td>
                </tr>
               <?php
               $i++;
                }
               ?>
                
            </tbody>
        </table>
    </div>
</div>

<?php
    require('./incl/footer.php');
    ?>