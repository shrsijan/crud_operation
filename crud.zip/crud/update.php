<?php

require 'dbconfig.php';

$title = $_POST['title'];
$content = $_POST['content'];
$created_at = date('Y-m-d');
$id = $_POST['id'];
$stmt = "UPDATE posts SET title='$title', content='$content', created_at='$created_at' WHERE id=$id";
$result = mysqli_query($connection, $stmt);
if($result)
{
    header("Location:list.php");
}
else
{
    echo 'data not inserted';
}