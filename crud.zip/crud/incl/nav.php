<nav class="navbar navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">Our App</a>
        </div>
    </nav>