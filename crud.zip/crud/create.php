<?php

require 'dbconfig.php';

$title = $_POST['title'];
$content = $_POST['content'];
$created_at = date('Y-m-d');


$stmt = "INSERT INTO posts(title, content, created_at)VALUES('$title', '$content', '$created_at')";
$result = mysqli_query($connection, $stmt);
if($result)
{
    header("Location:list.php");
}
else
{
    echo 'data not inserted';
}