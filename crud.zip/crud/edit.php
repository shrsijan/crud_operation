
    <?php
    require './incl/header.php';
    require './incl/nav.php';
    require 'dbconfig.php';
    $id = $_GET['id'];
    $stmt = "SELECT * FROM posts WHERE id=$id";
    $result = mysqli_query($connection, $stmt);
    $row = mysqli_fetch_array($result);
    ?>

    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                Edit Post
            </div>
            <div class="card-body">
                <form action="update.php" method="post">
                    <div class="mb-3">
                        <label for="title" class="form-label">Post Title</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?=$row['title'];?>">
                    </div>
                    <div class="mb-3">
                        <label for="body" class="form-label">Post Content</label>
                        <textarea class="form-control" id="body" rows="3" name="content"><?=$row['content']; ?> </textarea>
                    </div>
                    <input type="hidden" name="id" value="<?=$row['id'];?>">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-warning">Reset</button>
                    <a href="list.php" class="btn btn-danger">Cancel</a>
                </form>
            </div>
        </div>
    </div>

    <?php
    require('./incl/footer.php');
    ?>


    