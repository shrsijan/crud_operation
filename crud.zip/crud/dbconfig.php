<?php
$connection= mysqli_connect('localhost', 'root', '', 'm17');

if(!$connection)
{
    die("something wrong!!");
}