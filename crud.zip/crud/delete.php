<?php

require 'dbconfig.php';


$id = $_GET['id'];
$stmt = "DELETE FROM posts WHERE id=$id";
$result = mysqli_query($connection, $stmt);
if($result)
{
    header("Location:list.php");
}
else
{
    echo 'data not deleted';
}